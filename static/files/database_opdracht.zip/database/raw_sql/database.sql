SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS openingsuur;
DROP TABLE IF EXISTS contactgegeven;
DROP TABLE IF EXISTS actor_rubriek;
DROP TABLE IF EXISTS gebruiker;
DROP TABLE IF EXISTS actor;
DROP TABLE IF EXISTS rubriek;
DROP TABLE IF EXISTS categorie;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE categorie (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    naam VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE rubriek (
    id VARCHAR(20) PRIMARY KEY,   -- bv: '11', '11.02', '11.02.04'
    naam VARCHAR(255) NOT NULL,
    level INT NOT NULL
);

CREATE TABLE gebruiker (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rol ENUM('administrator', 'actorbeheerder') NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    wachtwoord VARCHAR(255) NOT NULL,
    actor_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE actor (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    publieke_naam VARCHAR(255) NOT NULL,

    categorie_id BIGINT UNSIGNED NOT NULL,

    betaalwijze ENUM('gratis', 'sociaal tarief', 'online betaling') NULL,

    leeftijdscategorie ENUM(
        'kinderen',
        'jongeren',
        'jongvolwassenen',
        'volwassenen',
        'ouderen'
    ) NULL,

    leeftijd_min INT NULL,
    leeftijd_max INT NULL,

    straatnaam VARCHAR(255),
    huisnummer VARCHAR(20),
    busnummer VARCHAR(20),
    gemeente VARCHAR(255),
    postcode VARCHAR(20),
    lat DECIMAL(10,8),
    lon DECIMAL(11,8),

    contactpersoon_gebruiker_id BIGINT UNSIGNED NULL,

    aangeboden_diensten TEXT,
    opmerkingen TEXT,
    last_updated DATE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (categorie_id) REFERENCES categorie(id),
    FOREIGN KEY (contactpersoon_gebruiker_id) REFERENCES gebruiker(id)
);


CREATE TABLE actor_rubriek (
    actor_id BIGINT UNSIGNED NOT NULL,
    rubriek_id VARCHAR(20) NOT NULL,

    PRIMARY KEY (actor_id, rubriek_id),

    FOREIGN KEY (actor_id) REFERENCES actor(id) ON DELETE CASCADE,
    FOREIGN KEY (rubriek_id) REFERENCES rubriek(id) ON DELETE CASCADE
);

CREATE TABLE contactgegeven (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    actor_id BIGINT UNSIGNED NOT NULL,
    type ENUM('mail', 'telefoonnr', 'online') NOT NULL,
    waarde VARCHAR(500) NOT NULL,

    FOREIGN KEY (actor_id) REFERENCES actor(id) ON DELETE CASCADE
);

CREATE TABLE openingsuur (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    actor_id BIGINT UNSIGNED NOT NULL,

    dag_van_de_week ENUM(
        'maandag',
        'dinsdag',
        'woensdag',
        'donderdag',
        'vrijdag',
        'zaterdag',
        'zondag'
    ) NOT NULL,

    startuur TIME NOT NULL,
    einduur TIME NOT NULL,

    type ENUM('online', 'open', 'op afspraak', 'telefonisch') NOT NULL,

    FOREIGN KEY (actor_id) REFERENCES actor(id) ON DELETE CASCADE
);