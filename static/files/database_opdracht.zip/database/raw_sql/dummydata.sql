
INSERT INTO categorie (id, naam) VALUES
(1, 'Vrije tijd'),
(2, 'Gezondheid');


INSERT INTO rubriek (id, naam, level) VALUES
('11', 'JONGEREN', 1),
('11.02', 'Jeugdwelzijnswerk', 2),
('11.02.04', 'Vrijetijdsinitiatieven', 3),
('02', 'LICHAMELIJKE GEZONDHEIDSZORG', 1),
('02.02', 'Dringende medische hulpverlening', 2),
('02.02.04', 'Tabakologen', 3);


INSERT INTO actor (id, publieke_naam, categorie_id, betaalwijze, leeftijdscategorie, leeftijd_min, leeftijd_max,
straatnaam, huisnummer, gemeente, postcode, lat, lon, aangeboden_diensten, last_updated)
VALUES
(1, 'Groep INTRO - Regio Limburg - Vestiging Sint-Truiden', 1, NULL, 'jongvolwassenen', 12, 25,
'Luikersteenweg', '7', 'Sint-Truiden', '3800', 50.81238628, 5.18875002,
'Vormingen rond vrije tijd, arbeid en onderwijs', '2025-01-01'),

(2, 'Gigos - Jeugdwelzijnswerk Genk', 1, NULL, 'jongeren', 12, 25,
'Bijlkestraat', '12', 'Genk', '3600', 50.93206384, 5.53125753,
'Jeugdwerking en ateliers', '2025-01-01'),

(3, 'PROFO vzw - Hasselt', 1, NULL, 'jongeren', 12, 25,
'Koningin Astridlaan', '33', 'Hasselt', '3500', 50.93161222, 5.33152526,
'Arbeidsgerichte trajecten voor jongeren', '2025-01-01'),

(4, 'Jeugdhuis Aurora', 1, NULL, 'jongeren', 12, 25,
'Ervaert', '1d', 'Tongeren-Borgloon', '3840', 50.8104278, 5.3421985,
'Ontmoetingsplek voor jongeren', '2025-01-01'),

(5, 'Paramedisch Centrum voor Obesitas & Diabetes', 2, 'sociaal tarief', 'volwassenen', 18, 99,
'Langenberg', '49', 'Diest', '3294', 50.99892039, 5.03049957,
'Behandeling obesitas en diabetes', '2025-01-01');


INSERT INTO actor_rubriek (actor_id, rubriek_id) VALUES
(1, '11'), (1, '11.02'),
(2, '11'), (2, '11.02'),
(3, '11'), (3, '11.02'),
(4, '11'), (4, '11.02'),
(5, '02'), (5, '02.02'), (5, '02.02.04');


INSERT INTO contactgegeven (actor_id, type, waarde) VALUES
(1, 'telefoonnr', '0473523900'),
(1, 'mail', 'maryam.jamshid@groepintro.be'),

(2, 'telefoonnr', '089258191'),
(2, 'mail', 'info@gigos.be'),

(3, 'telefoonnr', '0488663796'),
(3, 'mail', 'karima.lakdim@profo.be'),

(4, 'telefoonnr', '0479332084'),
(4, 'mail', 'bert.cordens@telenet.be'),

(5, 'telefoonnr', '013328731'),
(5, 'mail', 'pascale@dietistindiest.be');


INSERT INTO openingsuur (actor_id, dag_van_de_week, startuur, einduur, type) VALUES
(1, 'maandag', '08:30', '16:00', 'open'),
(1, 'dinsdag', '08:30', '16:00', 'open'),

(2, 'maandag', '09:00', '17:00', 'open'),
(2, 'dinsdag', '09:00', '17:00', 'open'),

(3, 'maandag', '08:30', '17:00', 'open'),
(3, 'dinsdag', '08:30', '17:00', 'open'),

(4, 'woensdag', '15:00', '01:00', 'open'),
(4, 'vrijdag', '15:00', '03:00', 'open'),

(5, 'zaterdag', '09:00', '13:00', 'op afspraak');
