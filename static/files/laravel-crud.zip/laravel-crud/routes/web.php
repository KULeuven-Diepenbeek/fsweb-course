<?php

use App\Http\Controllers\StudentController;
use App\Models\Student;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('studenten')->with('create_succes', true);
})->name('studenten');

Route::post('/create-student', [StudentController::class, "store"]);

Route::post('/update-student', [StudentController::class, "update"]);

Route::post('/delete-student', [StudentController::class, "destroy"]);

Route::get('/show-student', [StudentController::class, "show"]);

Route::get('/test', function () {
    $student = Student::factory()->count(10)->create();
    dd($student);
});
