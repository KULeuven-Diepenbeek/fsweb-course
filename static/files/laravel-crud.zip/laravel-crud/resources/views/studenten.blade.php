<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CRUD studenten application</title>
</head>

<body>
    <h3>Create a student</h3>
    <form action="/create-student" method="POST">
        @csrf
        <label for="studnr">Studenten nummer:</label>
        <input type="number" placeholder="123" id="studnr" name="studnr">

        <label for="voornaam">Vooraam:</label>
        <input type="text" placeholder="TestVoornaam" id="voornaam" name="voornaam">

        <label for="naam">Naam:</label>
        <input type="text" placeholder="TestNaam" id="naam" name="naam">

        <label for="goedBezig">Goed bezig:</label>
        <input type="checkbox" checked id="goedBezig" name="goedBezig">

        <button type="submit">Submit</button>
    </form>

    <h3>Update student</h3>
    <form action="/update-student" method="POST">
        @csrf
        <label for="studnr">Studenten nummer:</label>
        <input type="number" placeholder="123" id="studnr" name="studnr">

        <label for="voornaam">Vooraam:</label>
        <input type="text" placeholder="TestVoornaam" id="voornaam" name="voornaam">

        <label for="naam">Naam:</label>
        <input type="text" placeholder="TestNaam" id="naam" name="naam">

        <label for="goedBezig">Goed bezig:</label>
        <input type="checkbox" id="goedBezig" name="goedBezig">

        <button type="submit">Submit</button>
    </form>

    <h3>Delete student</h3>
    <form action="/delete-student" method="POST">
        @csrf
        <label for="studnr">Studenten nummer:</label>
        <input type="number" placeholder="123" id="studnr" name="studnr">

        <button type="submit">Submit</button>
    </form>

    <h3>Show student</h3>
    <form action="/show-student" method="GET">
        @csrf
        <label for="studnr">Studenten nummer:</label>
        <input type="number" placeholder="123" id="studnr" name="studnr">

        <button type="submit">Submit</button>
    </form>

</body>

</html>