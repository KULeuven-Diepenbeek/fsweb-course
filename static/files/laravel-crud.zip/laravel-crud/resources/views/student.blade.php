<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CRUD studenten application</title>
</head>

<body>
    <ul><strong>Studenten nummer:</strong> {{ $student->studnr }}</ul>
    <ul><strong>Voornaam:</strong> {{ $student->voornaam }}</ul>
    <ul><strong>Naam:</strong> {{ $student->naam }}</ul>
    @if ($student->goedBezig)
        <ul><strong>Goed bezig:</strong> ✔️</ul>
    @else
        <ul><strong>Goed bezig:</strong> ❌</ul>
    @endif

</body>

</html>
