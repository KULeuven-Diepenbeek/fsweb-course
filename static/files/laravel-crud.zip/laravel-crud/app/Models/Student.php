<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Student extends Model
{
    use HasFactory;
    // Define the primary key (studnr instead of default 'id')
    protected $primaryKey = 'studnr';
    public $incrementing = false; // Moet je nu dus ook wel toevoegen aan $fillable !!!


    // Fields that can be mass-assigned
    protected $fillable = [
        'studnr', // Aangezien dit nu geen auto-increment is
        'voornaam',
        'naam',
        'goedBezig',
    ];

    // Cast 'goedBezig' to boolean
    protected $casts = [
        'goedBezig' => 'boolean',
    ];
}
