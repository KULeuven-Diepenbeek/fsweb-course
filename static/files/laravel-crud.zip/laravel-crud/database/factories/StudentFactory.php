<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Student>
 */
class StudentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'studnr' => $this->faker->unique()->numberBetween(1000, 2000),
            'voornaam' => $this->faker->firstName(),
            'naam' => $this->faker->lastName(),
            'goedBezig' => $this->faker->boolean(),
        ];
    }
}
