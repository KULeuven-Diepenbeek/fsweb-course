<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            // Custom primary key (studnr) as auto-incrementing integer
            $table->integer('studnr')->primary();

            // voornaam (string, NOT NULL)
            $table->string('voornaam')->nullable(false);

            // naam (string, nullable)
            $table->string('naam')->nullable();

            // goedBezig (boolean with default value)
            $table->boolean('goedBezig')->default(false);

            // Timestamps (created_at and updated_at)
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('students');
    }
};
