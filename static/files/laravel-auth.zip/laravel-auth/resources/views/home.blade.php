<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Auth example</title>

</head>

<body>
    @guest
        <a href={{ route('login') }}>login</a>
    @endguest

    @auth
        <h1>Welcome to home {{ Auth::user()->name }}</h1>
        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit">logout</button>
        </form>
    @endauth

    @if (session()->has('key1'))
        <p><strong>{{ session('key1') }}</strong></p>
    @endif
    <p><strong>{{ session('status', 'default') }}</strong></p>
</body>

</html>
