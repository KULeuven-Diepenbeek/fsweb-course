<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="{{ route('createuser') }}" method="POST">
        @csrf
        <label for="name">name:</label>
        <input type="text" value="{{ old('name') }}" placeholder="Test" id="name" name="name">
        <label for="email">email:</label>
        <input type="email" value="{{ old('email') }}" placeholder="test@test.com" id="email" name="email">
        <label for="password">pwd:</label>
        <input type="text" placeholder="TestPWD$" id="password" name="password">
        <label for="password_confirmation">pwd confirm:</label>
        <input type="text" placeholder="TestPWD$" id="password_confirmation" name="password_confirmation">
        <button type="submit">register</button>
    </form>
    <br /> <br />
    <form action="/login-user" method="GET">
        @csrf
        <label for="email">email:</label>
        <input type="email" value="{{ old('email') }}" placeholder="test@test.com" id="email" name="email">
        <label for="password">pwd:</label>
        <input type="text" id="password" name="password">
        <button type="submit">login</button>
    </form>

    @if ($errors->any())
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

</body>

</html>
