<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home');
})->name('home');

Route::get('/home2', function () {
    return view('home2');
})->middleware('auth');
// // OR
// Route::middleware('auth')->group(function () {
//     Route::get('/home2', function () {
//         return view('home2');
//     });
// });

Route::get('/contact', function () {
    return view('contact');
})->name('contact');

Route::get('/login', function () {
    return view('login');
})->name('login');

Route::post('/create-user', [UserController::class, "store"])->name("createuser");
Route::get('/login-user', [UserController::class, "show"]);
Route::post('/logout', [UserController::class, "logout"])->name("logout");

// // OR
// Route::controller(UserController::class)->group(function () {
//     Route::post('/create-user', "store")->name("createuser");
//     Route::get('/login-user', "show");
//     Route::post('/logout', "logout")->name("logout");
// });
