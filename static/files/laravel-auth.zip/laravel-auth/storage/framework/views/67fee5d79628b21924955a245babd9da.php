<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Auth example</title>

</head>

<body>
    <?php if(auth()->guard()->guest()): ?>
        <a href=<?php echo e(route('login')); ?>>login</a>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <h1>Welcome to home <?php echo e(Auth::user()->name); ?></h1>
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit">logout</button>
        </form>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\dashboard\laravel-auth\resources\views/home2.blade.php ENDPATH**/ ?>