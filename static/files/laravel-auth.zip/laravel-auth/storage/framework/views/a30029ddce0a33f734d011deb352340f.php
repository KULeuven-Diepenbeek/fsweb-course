<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="<?php echo e(route('createuser')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="name">name:</label>
        <input type="text" value="Test" placeholder="Test" id="name" name="name">
        <label for="email">email:</label>
        <input type="email" value="<?php echo e(old('email')); ?>" placeholder="test@test.com" id="email" name="email">
        <label for="password">pwd:</label>
        <input type="text" value="TestPWD$" placeholder="TestPWD$" id="password" name="password">
        <label for="password_confirmation">pwd:</label>
        <input type="text" value="TestPWD$" placeholder="TestPWD$" id="password_confirmation"
            name="password_confirmation">
        <button type="submit">register</button>
    </form>

    <form action="/login-user" method="GET">
        <?php echo csrf_field(); ?>
        <label for="email">email:</label>
        <input type="email" value="test@test.com" placeholder="test@test.com" id="email" name="email">
        <label for="password">pwd:</label>
        <input type="text" value="TestPWD$" placeholder="TestPWD$" id="password" name="password">
        <button type="submit">login</button>
    </form>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\dashboard\laravel-auth\resources\views/login.blade.php ENDPATH**/ ?>