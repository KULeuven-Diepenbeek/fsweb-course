<?php

use App\Models\Opleiding;
use App\Models\Student;
use App\Models\Vak;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    var_dump('Voor een student de opleiding en vakken ophalen:');
    // Voor een student de opleiding en vakken ophalen:
    var_dump('--Student');
    // -- Met `first()` krijg je gewoon het eerste object in de tabel uit de database.
    $student = Student::first();
    dump($student);
    var_dump('--Opleiding');
    $opleiding = $student->opleiding;
    dump($opleiding);
    var_dump('--Vakken');
    $vakken = $student->vakken;
    dump($vakken);

    var_dump('------------------------------------------------------------');

    var_dump('Voor een opleiding alle studenten ophalen:');
    // Voor een opleiding alle studenten ophalen:
    var_dump('--Opleiding');
    $opleiding = Opleiding::first();
    dump($opleiding);
    var_dump('--Studenten');
    $studenten = $opleiding->students;
    dump($studenten);

    var_dump('------------------------------------------------------------');

    var_dump('Voor een vak alle studenten ophalen:');
    // Voor een vak alle studenten ophalen:
    var_dump('--Vak');
    $vak = Vak::first();
    dump($vak);
    var_dump('--Studenten');
    $studenten = $vak->students;
    dd($studenten);
});
