<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    // Define the primary key (studnr instead of default 'id')
    protected $primaryKey = 'studnr';

    // Fields that can be mass-assigned
    protected $fillable = [
        'voornaam',
        'naam',
        'goedBezig',
        'opleiding_id',
    ];

    // Cast 'goedBezig' to boolean
    protected $casts = [
        'goedBezig' => 'boolean',
    ];

    // Voeg relaties toe:
    public function opleiding()
    {
        return $this->belongsTo(Opleiding::class, 'opleiding_id');
    }

    public function vakken()
    {
        return $this->belongsToMany(Vak::class, 'student_vak', 'student_studnr', 'vak_vaknr');
    }
}
