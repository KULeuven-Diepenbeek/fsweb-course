<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vak extends Model
{
    use HasFactory;

    protected $primaryKey = 'vaknr';
    public $incrementing = true;

    protected $fillable = ['naam'];

    public function students()
    {
        return $this->belongsToMany(Student::class, 'student_vak', 'vak_vaknr', 'student_studnr');
    }
}
