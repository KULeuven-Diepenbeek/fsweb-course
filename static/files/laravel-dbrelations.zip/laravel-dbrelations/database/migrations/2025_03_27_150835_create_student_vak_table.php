<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('student_vak', function (Blueprint $table) {
            $table->integer('student_studnr'); // Komt overeen met het type van 'studnr' in students
            $table->integer('vak_vaknr');     // Komt overeen met het type van 'vaknr' in vaks

            $table->foreign('student_studnr')->references('studnr')->on('students')->onDelete('cascade');
            $table->foreign('vak_vaknr')->references('vaknr')->on('vaks')->onDelete('cascade');

            $table->primary(['student_studnr', 'vak_vaknr']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('student_vak');
    }
};
