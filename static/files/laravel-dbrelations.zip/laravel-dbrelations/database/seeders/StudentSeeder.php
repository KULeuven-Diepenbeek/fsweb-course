<?php

namespace Database\Seeders;

use App\Models\Opleiding;
use App\Models\Student;
use App\Models\Vak;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Maak 3 opleidingen
        $opleidingen = Opleiding::factory()->count(3)->create();

        // Maak 5 vakken
        $vakken = Vak::factory()->count(5)->create();

        // Maak 10 studenten en koppel opleiding en vakken
        Student::factory()
            ->count(10)
            ->create(['opleiding_id' => $opleidingen->random()->id])
            ->each(function ($student) use ($vakken) {
                // Voor ELKE student die net aangemaakt is:

                // Koppel vakken via de many-to-many relatie
                $student->vakken()->attach(
                    // Selecteer 2 willekeurige vakken uit de collectie van $vakken
                    $vakken->random(2)
                        // Pluck de 'vaknr' (primary key) van deze 2 vakken
                        ->pluck('vaknr')
                        // Zet het resultaat om naar een array van IDs
                        ->toArray()
                );

                // Dit voegt 2 records toe aan de koppeltabel 'student_vak' bv:
                // [
                //   ['student_studnr' => 123, 'vak_vaknr' => 1],
                //   ['student_studnr' => 123, 'vak_vaknr' => 3]
                // ]
            });
    }
}
