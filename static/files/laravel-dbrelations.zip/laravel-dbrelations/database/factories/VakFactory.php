<?php

namespace Database\Factories;

use App\Models\Vak;
use Illuminate\Database\Eloquent\Factories\Factory;

class VakFactory extends Factory
{
    protected $model = Vak::class;

    public function definition()
    {
        return [
            'naam' => $this->faker->unique()->words(2, true),
        ];
    }
}
