<?php

namespace Database\Factories;

use App\Models\Student;
use Illuminate\Database\Eloquent\Factories\Factory;

class StudentFactory extends Factory
{
    protected $model = Student::class;

    public function definition()
    {
        return [
            'voornaam' => $this->faker->firstName(),
            'naam' => $this->faker->lastName(),
            'goedBezig' => $this->faker->boolean(),
        ];
    }
}
