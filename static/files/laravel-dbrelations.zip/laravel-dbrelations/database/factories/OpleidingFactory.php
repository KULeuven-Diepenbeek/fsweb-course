<?php

namespace Database\Factories;

use App\Models\Opleiding;
use Illuminate\Database\Eloquent\Factories\Factory;

class OpleidingFactory extends Factory
{
    protected $model = Opleiding::class;

    public function definition()
    {
        return [
            'naam' => $this->faker->unique()->word(),
        ];
    }
}
